package com.example.CommunityClinicDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommunityClinicDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommunityClinicDemoApplication.class, args);
	}

}
